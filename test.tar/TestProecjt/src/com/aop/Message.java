package com.aop;

public class Message implements IMessage {

	@Override
	public String saySomething(String message) {
		// TODO Auto-generated method stub
		return message;
	}

}
