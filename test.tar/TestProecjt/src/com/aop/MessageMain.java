package com.aop;

public class MessageMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IMessage imessage = (IMessage) new AllInvocationHandler(new Message()).getProxy();
		System.out.println(imessage.saySomething("Hi Message Invocation Handler"));
		
		IMessage imessageInterceptor = (IMessage) new AllInterceptor(new Message()).getProxy();
		System.out.println(imessageInterceptor.saySomething("Hi Message Interceptor"));
		
	}

}
