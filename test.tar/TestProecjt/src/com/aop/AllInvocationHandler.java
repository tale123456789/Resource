package com.aop;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class AllInvocationHandler implements InvocationHandler {
	private Object target;

	public AllInvocationHandler(Object target) {
		this.target = target;
	}

	public Object getProxy() {
		return Proxy.newProxyInstance(target.getClass().getClassLoader(), 
				                      target.getClass().getInterfaces(),
				                      new AllInvocationHandler(target));
		


	}

	@Override
	public Object invoke(Object object, Method method, Object[] arg) throws Throwable {
		// TODO Auto-generated method stub	

		return method.invoke(this.target, arg);
	}

}
