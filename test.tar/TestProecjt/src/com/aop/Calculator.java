package com.aop;

public class Calculator implements ICalculator {

	@Override
	public double add(double a, double b) {
		// TODO Auto-generated method stub
		return a + b;
	}

	@Override
	public double sub(double a, double b) {
		// TODO Auto-generated method stub
		return a - b;
	}

	@Override
	public double mul(double a, double b) {
		// TODO Auto-generated method stub
		return a * b;
	}

	@Override
	public double div(double a, double b) throws Exception{
		// TODO Auto-generated method stub
		if (b == 0) {
			throw new IllegalArgumentException("divisor is 0!");
		}
		return a / b;
	}

}
