package com.aop;

public class CalculatorDecorator implements ICalculator {
 
	private ICalculator iCalculator;
	
	public CalculatorDecorator(ICalculator iCalculator) {
		this.iCalculator = iCalculator;
	}
	
	@Override
	public double add(double a, double b) {
		// TODO Auto-generated method stub
		return iCalculator.add(a, b);
	}

	@Override
	public double sub(double a, double b) {
		// TODO Auto-generated method stub
		return iCalculator.sub(a, b);
	}

	@Override
	public double mul(double a, double b) {
		// TODO Auto-generated method stub
		return iCalculator.mul(a, b);
	}

	@Override
	public double div(double a, double b) throws Exception {
		// TODO Auto-generated method stub
		return iCalculator.div(a, b);
	}

}
