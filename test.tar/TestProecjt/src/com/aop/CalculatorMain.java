package com.aop;

public class CalculatorMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        CalculatorDecorator calculatorDecorator = new CalculatorDecorator(new Calculator());
        System.out.println("add = "+calculatorDecorator.add(11, 21));
        System.out.println("sub = "+calculatorDecorator.sub(11, 21));
        System.out.println("mul = "+calculatorDecorator.mul(11, 21));
        try {
        	System.out.println("div = "+calculatorDecorator.div(99, 0));	
        }catch(Exception e) {
        	System.out.println(e.getMessage());
        }
        
        AllInvocationHandler calculatorInvocationHandler = new AllInvocationHandler(new Calculator());
        ICalculator icalculator = (ICalculator)calculatorInvocationHandler.getProxy();
        System.out.println("add = "+icalculator.add(11, 21));
        


        
	}

}
