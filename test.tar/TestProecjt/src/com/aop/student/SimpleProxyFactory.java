package com.aop.student;

import java.lang.reflect.Proxy;

public class SimpleProxyFactory {
    
	private SimpleProxyFactory() {}
	
	public static Object newInstance(Object target, ILogAspect iLogAspect) {
		
		LogInvocationHandler logInvocationHandler = new LogInvocationHandler(target);
		
		logInvocationHandler.setAspectList(iLogAspect);
		
		return logInvocationHandler.getProxy();
	}
	
	
}
