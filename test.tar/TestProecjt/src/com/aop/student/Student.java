package com.aop.student;

public class Student implements IStudent {
	
	public void sayHello()
	{
		System.out.println("hello ,i am tom");
	}

}
