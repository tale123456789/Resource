package com.aop.student;

public class LogAspect implements ILogAspect {

	@Override
	public void before() {
		// TODO Auto-generated method stub
        System.out.println("LogAspect Before");
	}

	@Override
	public void after() {
		// TODO Auto-generated method stub
		System.out.println("LogAspect After");
	}

}
