package com.aop.student;

 public interface IStudent {
	 void sayHello();//
}
 
