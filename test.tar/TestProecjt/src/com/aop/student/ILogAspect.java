package com.aop.student;

public interface ILogAspect  {
    public abstract void before();
    public abstract void after();
}
