package com.aop.student;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ILogAspect  iLogAspect = new LogAspect();   
		
		IStudent s = (IStudent) SimpleProxyFactory.newInstance(new Student(), iLogAspect);
		
        s.sayHello();
	}

}
