package com.aop.student;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;



public class LogInvocationHandler implements InvocationHandler{
    private Object target;
    private List<ILogAspect> aspectList= new ArrayList<ILogAspect>();
    
    public LogInvocationHandler(Object target) {
    	this.target = target;
    }
    
    
    
    public Object getTarget() {
		return target;
	}


	public void setAspectList(ILogAspect iLogAspect) {
    	aspectList.add(iLogAspect);
    }
    
    public Object getProxy() {
    	return Proxy.newProxyInstance(this.target.getClass().getClassLoader(), 
    			                      this.target.getClass().getInterfaces(), 
    			                      this);//new LogInvocationHandler(this.target));
    	
    }
	
	@Override
	public Object invoke(Object object, Method method, Object[] arg) throws Throwable {
		// TODO Auto-generated method stub
		for(ILogAspect iLogAspect : aspectList) {
			iLogAspect.before();
		}		
		
		Object rtn = method.invoke(this.target, arg);
		
		for(ILogAspect iLogAspect : aspectList) {
			iLogAspect.after();
		}
		return rtn;
	}

}
