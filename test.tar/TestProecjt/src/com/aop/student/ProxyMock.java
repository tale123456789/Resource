package com.aop.student;

import java.lang.reflect.Method;

public class ProxyMock implements IStudent {

	private LogInvocationHandler logInvocationHandler;
	
	public ProxyMock(LogInvocationHandler logInvocationHandler) {
        this.logInvocationHandler = logInvocationHandler;
	}
	
	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
        try {
			Method method = logInvocationHandler.getTarget().getClass().getMethod("sayHello", null);
			logInvocationHandler.invoke(this, method, null);
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LogInvocationHandler logInvocationHandler = new LogInvocationHandler(new Student());
		logInvocationHandler.setAspectList(new LogAspect());
		
		
		ProxyMock proxyMock = new ProxyMock(logInvocationHandler);
		proxyMock.sayHello();
	}

}
