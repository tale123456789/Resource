package com.aop;

import java.lang.reflect.Method;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

public class AllInterceptor implements MethodInterceptor{
    private Object target;
	
    public AllInterceptor(Object target) {
    	this.target = target;
    }
	
    public Object getProxy() {
    	return Enhancer.create(this.target.getClass(), 
    			               this);//new AllInterceptor(this.target));
    }
    
	@Override
	public Object intercept(Object object, Method method, Object[] args, MethodProxy invocation) throws Throwable {
		// TODO Auto-generated method stub
		return invocation.invoke(this.target, args);
	}

}
