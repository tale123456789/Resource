package com.aop;

public interface IMessage {
    public abstract String saySomething(String message);
}
