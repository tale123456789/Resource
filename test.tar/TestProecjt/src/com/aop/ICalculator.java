package com.aop;

public interface ICalculator {
    public abstract double add(double a, double b);
    public abstract double sub(double a, double b);
    public abstract double mul(double a, double b);
    public abstract double div(double a, double b) throws Exception;
}
