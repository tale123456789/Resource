
public class TestThread2 implements Runnable{
  long sleep_time;
  String process_name;
	
   public TestThread2(long sleep_time, String process_name) {
	   this.sleep_time = sleep_time;
	   this.process_name = process_name;
   }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        new Thread(new TestThread2(1001, "11")).start();
        new Thread(new TestThread2(3001, "22")).start();
        new Thread(new TestThread2(4001, "33")).start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			try {
				Thread.sleep(sleep_time);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(process_name);
		}
	}

}
