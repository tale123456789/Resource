public class TestThread extends Thread {
    long wait_time;
    String name;
	
	public TestThread(long wait_time, String name) {
		this.wait_time = wait_time;
		this.name = name;
	}
	
	public void run() {
		while(true) {
			try {
				Thread.sleep(wait_time);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(name);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 1000�@�� = 1�� 
	    // ��start �ӱҰ�thread 
	    (new TestThread(3 * 1000, "Thread-1")).start(); 
	    (new TestThread(1 * 1000, "Thread-2")).start(); 
	}

}
