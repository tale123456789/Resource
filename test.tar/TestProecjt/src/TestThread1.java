
public class TestThread1 extends Thread {
    long sleep_time;
    String process_name;
    
    public TestThread1(long sleep_time, String process_name) {
    	this.sleep_time = sleep_time;
    	this.process_name = process_name;
    }
	
	public void run() {
		while (true) {
			try {
				sleep(sleep_time);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(process_name);
		}
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        new TestThread1(1033,"1").start();;
        new TestThread1(6999, "2").start();;
	}

}
