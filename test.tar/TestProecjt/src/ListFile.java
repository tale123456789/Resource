import java.io.File;
import java.util.Scanner;

public class ListFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Input path=");
		String path = s.nextLine();//"D:\\App\\apache-tomcat-8.5.27"
		File f = new File(path);
		File[] ff = f.listFiles();
		for (File fff : ff) {
			deepDir(fff);
		}
	}

	public static void deepDir(File f) {
		if (f.isFile()) {
			System.out.println(f.getAbsolutePath());
		} else
			for (File ff : f.listFiles()) {
				deepDir(new File(ff.getAbsolutePath()));
			}

	}

}
