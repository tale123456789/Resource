import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class No146 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		Foo serialFoo = new Foo("12", "ab");
        System.out.println(serialFoo);;
        
			FileOutputStream fos = new FileOutputStream("No146");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(serialFoo);
			oos.flush();
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		try {
			FileInputStream fis = new FileInputStream("No146");
			ObjectInputStream ois = new ObjectInputStream(fis);
			Foo deserailFoo = (Foo)ois.readObject();
			System.out.println(deserailFoo);
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}

class Foo implements Serializable {
	public String a, b;
	public Foo(String a, String b) {
		this.a = a;
		this.b = b;
	}
	public String toString() {
		return a+" "+b;
	}
}
